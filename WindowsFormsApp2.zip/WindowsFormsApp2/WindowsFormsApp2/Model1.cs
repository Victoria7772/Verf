using System;
using System.ComponentModel.DataAnnotations.Schema;
using System.Data.Entity;
using System.Linq;

namespace WindowsFormsApp2
{
    public partial class Model1 : DbContext
    {
        public Model1()
            : base("name=Model1")
        {
        }

        public virtual DbSet<AccessoriesToBoat> AccessoriesToBoat { get; set; }
        public virtual DbSet<Accessory> Accessory { get; set; }
        public virtual DbSet<Boat> Boat { get; set; }
        public virtual DbSet<Contract> Contract { get; set; }
        public virtual DbSet<Customers> Customers { get; set; }
        public virtual DbSet<Invoice> Invoice { get; set; }
        public virtual DbSet<Order> Order { get; set; }
        public virtual DbSet<Order_details> Order_details { get; set; }
        public virtual DbSet<Partner> Partner { get; set; }

        internal void SaveChanges(object usr)
        {
            throw new NotImplementedException();
        }

        public virtual DbSet<SalesPerson> SalesPerson { get; set; }
        public virtual DbSet<Users> Users { get; set; }

        protected override void OnModelCreating(DbModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Accessory>()
                .Property(e => e.Accessory_ID)
                .IsFixedLength();

            modelBuilder.Entity<Accessory>()
                .Property(e => e.Partner_ID)
                .IsFixedLength();

            modelBuilder.Entity<Boat>()
                .Property(e => e.boat_ID)
                .IsFixedLength();

            modelBuilder.Entity<Boat>()
                .Property(e => e.BasePrice)
                .HasPrecision(19, 4);

            modelBuilder.Entity<Contract>()
                .Property(e => e.Order_ID)
                .IsFixedLength();

            modelBuilder.Entity<Contract>()
                .Property(e => e.Salesperson_ID)
                .IsFixedLength();

            modelBuilder.Entity<Contract>()
                .Property(e => e.Customer_ID)
                .IsFixedLength();

            modelBuilder.Entity<Contract>()
                .Property(e => e.Boat_ID)
                .IsFixedLength();

            modelBuilder.Entity<Customers>()
                .Property(e => e.Customer_ID)
                .IsFixedLength();

            modelBuilder.Entity<Invoice>()
                .Property(e => e.Invoice_ID)
                .IsFixedLength();

            modelBuilder.Entity<Invoice>()
                .Property(e => e.Sum)
                .HasPrecision(19, 4);

            modelBuilder.Entity<Order>()
                .Property(e => e.Contarct_ID)
                .IsFixedLength();

            modelBuilder.Entity<Order_details>()
                .Property(e => e.Detail_ID)
                .IsFixedLength();

            modelBuilder.Entity<Order_details>()
                .Property(e => e.Accessory_ID)
                .IsFixedLength();

            modelBuilder.Entity<Order_details>()
                .Property(e => e.Order_ID)
                .IsFixedLength();

            modelBuilder.Entity<Partner>()
                .Property(e => e.Partner_ID)
                .IsFixedLength();

            modelBuilder.Entity<Users>()
                .Property(e => e.ID)
                .IsFixedLength();
        }
    }
}
