namespace WindowsFormsApp2
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("Contract")]
    public partial class Contract
    {
        [Key]
        [StringLength(10)]
        public string Order_ID { get; set; }

        [Column(TypeName = "date")]
        public DateTime Date { get; set; }

        [Required]
        [StringLength(10)]
        public string Salesperson_ID { get; set; }

        [Required]
        [StringLength(10)]
        public string Customer_ID { get; set; }

        [Required]
        [StringLength(10)]
        public string Boat_ID { get; set; }

        [Required]
        [StringLength(50)]
        public string DeliveryAddress { get; set; }

        [Required]
        [StringLength(50)]
        public string City { get; set; }
    }
}
