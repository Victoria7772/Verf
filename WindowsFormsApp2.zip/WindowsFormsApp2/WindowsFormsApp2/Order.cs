namespace WindowsFormsApp2
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("Order")]
    public partial class Order
    {
        [Key]
        [StringLength(10)]
        public string Contarct_ID { get; set; }

        [Column(TypeName = "date")]
        public DateTime Date { get; set; }

        [Required]
        [StringLength(50)]
        public string DepositPayed { get; set; }

        public int Order_ID { get; set; }

        [Required]
        [StringLength(50)]
        public string ContractTotalPrice { get; set; }

        [Required]
        [StringLength(50)]
        public string ContracTotalPrice_inclVAT { get; set; }

        [Required]
        public string ProductionProcess { get; set; }
    }
}
