namespace WindowsFormsApp2
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("Invoice")]
    public partial class Invoice
    {
        [Key]
        [StringLength(10)]
        public string Invoice_ID { get; set; }

        public int Contract_ID { get; set; }

        [Required]
        [StringLength(50)]
        public string Settled { get; set; }

        [Column(TypeName = "money")]
        public decimal Sum { get; set; }

        public double Sum_inclVAT { get; set; }

        [Column(TypeName = "date")]
        public DateTime Date { get; set; }
    }
}
